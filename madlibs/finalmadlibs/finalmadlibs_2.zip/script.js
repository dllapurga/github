/* JS Card Slide Off After Submit */

(function () {

  'use strict';
  console.log('reading js');

  const form = document.querySelector('form');

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    const firstname = document.querySelector('#firstname').value;
    const adj1 = document.querySelector('#adjective1').value;
    const adj2 = document.querySelector('#adjective2').value;
    const adj3 = document.querySelector('#adjective3').value;
    const noun = document.querySelector('#noun').value;
    const adverb = document.querySelector('#adverb').value;
    const medical = document.querySelector('#medicalcondition').value;
    const adj4 = document.querySelector('#adjective4').value;
    const firstname2 = document.querySelector('#firstname2').value;
    const lastname = document.querySelector('#lastname').value;
    


    const story = `<p>Dear ${firstname},</p>
      <p>
        I hope this postcard finds you ${adjective1}. I finally made it to
        San Francisco and this place is absolutely ${adjective2}.
        And the people here are ${adjective3}.
      </p>
      <p>
        On the flight here, there was a ${noun} seated behind me and it was
        ${adverb} kicking my chair the whole flight. Eventually, I had to
        turn around and say, "Please stop kicking, you're going to give me
        ${medical}."
      </p>
      <p>
        Anyway, I've really enjoyed my time here so far. I've never been more
        ${adjective4}. Because I start my job next week, I won't be able to
        write you for a while.
      </p>
      <p>
        Sincerely,<br>
        ${firstname2} ${lastname}
      </p>`;


    document.querySelector('#current-card').classList.add('slide-out'); 
    document.querySelector('#next-card').classList.add('slide-in');


   
  });

})();


