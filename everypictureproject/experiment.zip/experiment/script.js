(function () {

  'use strict';
  console.log('reading js');

const img = document.querySelector('.intensity-img');

img.addEventListener('mousemove', (e) => {
  const rect = img.getBoundingClientRect();
  const x = e.clientX - rect.left;       
  const percent = x / rect.width;       

  const grayscale = 100 - percent * 100;  // 100 → 0
  img.style.filter = `grayscale(${grayscale}%)`;
});

img.addEventListener('mouseleave', () => {
  img.style.filter = 'grayscale(100%)';
});

}) ();